import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// We will use the Flash model for fast, multimodal chat interactions
const MODEL_NAME = "gemini-3-flash-preview";

/**
 * Sends a message to the Gemini model acting as a specific persona.
 * 
 * @param personaName The name of the simulated user (e.g., "Alice")
 * @param history The chat history to provide context
 * @param newMessage The new text message from the user
 * @param file Optional file data (base64)
 */
export const sendMessageToGemini = async (
  personaName: string,
  history: Message[],
  newMessage: string,
  file?: { data: string; mimeType: string }
): Promise<string> => {
  try {
    // Construct the prompt. 
    // Since we are simulating a specific person, we add a system instruction via the prompt 
    // or system config. For simplicity in a stateless request, we'll prepend context.
    
    // We strictly use the stateless generateContent here for simplicity in handling
    // multiple "personas" without managing complex ChatSession objects in the service.
    // We pass the conversation context manually if needed, or just the current prompt.
    // For a better experience, we'll give it a system instruction in the config.

    const systemInstruction = `Tu es ${personaName}. Tu discutes avec un ami sur une application de chat style WhatsApp. 
    Réponds de manière concise, naturelle et amicale. Si on t'envoie une image, analyse-la. 
    Ne sois pas trop formel. Utilise des emojis occasionnellement.`;

    const parts: any[] = [];

    // Add file if present
    if (file) {
      parts.push({
        inlineData: {
          mimeType: file.mimeType,
          data: file.data,
        },
      });
    }

    // Add text
    // We include a simplified history context in the text prompt to simulate memory
    // (Optimization: In a real production app, use 'history' prop of chat.sendMessage)
    const recentHistory = history.slice(-5).map(m => 
      `${m.senderId === 'me' ? 'Moi' : personaName}: ${m.text}`
    ).join('\n');

    const promptText = `
    ${recentHistory ? `Historique récent:\n${recentHistory}\n` : ''}
    Moi: ${newMessage}
    `;

    parts.push({ text: promptText });

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        role: "user",
        parts: parts
      },
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "";
  } catch (error) {
    console.error("Erreur Gemini:", error);
    return "Désolé, je n'ai pas pu traiter ta demande pour le moment.";
  }
};
